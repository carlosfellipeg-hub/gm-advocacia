# GM Advocacia — Site Premium

Site de landing page para o escritório Gabriella Magalhães Advocacia.

## Stack
- Next.js 14.2.5
- React Three Fiber + Drei (placa 3D no Hero)
- Framer Motion (animações scroll-driven)
- Lenis (smooth scroll)
- Tailwind CSS
- TypeScript

## Instalação e execução

```bash
# Instalar dependências
npm install

# Executar em desenvolvimento
npm run dev

# Build de produção
npm run build
npm start
```

## Estrutura

```
├── app/
│   ├── layout.tsx         # Layout raiz (fontes, metadata)
│   ├── page.tsx           # Página principal
│   └── globals.css        # Estilos globais + tokens
├── components/
│   ├── 3d/
│   │   ├── GMPlaque.tsx   # Placa 3D em latão com monograma
│   │   └── HeroScene.tsx  # Canvas R3F
│   └── sections/
│       ├── HeroSection.tsx
│       ├── IntroSection.tsx
│       ├── AreasSection.tsx
│       ├── SobreSection.tsx
│       ├── AutoridadeSection.tsx
│       ├── ResultadosSection.tsx
│       └── ContatoSection.tsx
└── public/
    └── images/
        ├── gabriella-estudio-1.jpeg
        ├── gabriella-estudio-2.jpeg
        ├── gabriella-ambiente.jpeg
        ├── equipe.jpeg
        └── card-decisoes.jpeg
```

## Customização necessária

1. **Número de WhatsApp**: Edite `ContatoSection.tsx`, linha com `WHATSAPP_NUMBER`
2. **Instagram**: Edite `ContatoSection.tsx` no bloco de info de contato
3. **Textos**: Todos os textos são facilmente editáveis em cada componente de seção

## Paleta
- Sand: `#EFE9DC`
- Ink: `#2B2520`
- Brass: `#C9A668`
- Walnut: `#5C4430`
