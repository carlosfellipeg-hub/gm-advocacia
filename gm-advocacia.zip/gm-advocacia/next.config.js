/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    unoptimized: false,
  },
  transpilePackages: ["three"],
};

module.exports = nextConfig;
