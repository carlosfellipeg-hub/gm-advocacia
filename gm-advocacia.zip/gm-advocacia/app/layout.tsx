import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
  axes: ["opsz"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Gabriella Magalhães | Advocacia Especializada",
  description:
    "Decisões familiares são decisões econômicas. Advocacia especializada em Direito de Família, Sucessões, Empresarial e Civil em todo o Brasil.",
  openGraph: {
    title: "Gabriella Magalhães | Advocacia Especializada",
    description: "Decisões familiares são decisões econômicas.",
    locale: "pt_BR",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className={`${fraunces.variable} ${inter.variable}`}>
      <body>{children}</body>
    </html>
  );
}
