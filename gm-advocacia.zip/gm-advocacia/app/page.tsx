"use client";

import { useEffect } from "react";
import dynamic from "next/dynamic";
import HeroSection from "@/components/sections/HeroSection";
import IntroSection from "@/components/sections/IntroSection";
import AreasSection from "@/components/sections/AreasSection";
import SobreSection from "@/components/sections/SobreSection";
import AutoridadeSection from "@/components/sections/AutoridadeSection";
import ResultadosSection from "@/components/sections/ResultadosSection";
import ContatoSection from "@/components/sections/ContatoSection";

export default function Home() {
  useEffect(() => {
    // Initialize Lenis smooth scroll
    let lenis: any;

    const initLenis = async () => {
      const Lenis = (await import("lenis")).default;
      lenis = new Lenis({
        duration: 1.4,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        smoothWheel: true,
      });

      function raf(time: number) {
        lenis.raf(time);
        requestAnimationFrame(raf);
      }

      requestAnimationFrame(raf);
    };

    initLenis();

    return () => {
      lenis?.destroy();
    };
  }, []);

  return (
    <main>
      <HeroSection />
      <IntroSection />
      <AreasSection />
      <SobreSection />
      <AutoridadeSection />
      <ResultadosSection />
      <ContatoSection />
    </main>
  );
}
