"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";

const testimonials = [
  {
    text: "A Dra. Gabriella conduziu meu processo de divórcio com uma delicadeza e eficiência que eu não esperava encontrar. Senti que minha história realmente importava.",
    author: "M. R.",
    context: "Direito de Família",
  },
  {
    text: "O planejamento sucessório que o escritório desenvolveu para nossa família foi essencial. Claro, completo e pensado para o longo prazo. Recomendo sem hesitar.",
    author: "C. F.",
    context: "Sucessões",
  },
  {
    text: "Precisava resolver uma questão societária delicada e o suporte do escritório foi impecável. Profissionalismo e agilidade do início ao fim.",
    author: "R. A.",
    context: "Empresarial",
  },
];

export default function ResultadosSection() {
  const [active, setActive] = useState(0);

  return (
    <section
      className="bg-ink py-28 md:py-40 px-8 md:px-16 overflow-hidden"
      id="resultados"
    >
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 md:gap-24 items-center">
        {/* Left: Team photo with overlay text */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="relative h-[480px] md:h-[580px] group"
        >
          <Image
            src="/images/equipe.jpeg"
            alt="Equipe GM Advocacia"
            fill
            className="object-cover object-center rounded-sm"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent rounded-sm" />
          <div className="absolute bottom-8 left-8 right-8">
            <p className="font-inter text-[10px] tracking-ultra uppercase text-brass mb-2">
              Atendimento em todo o Brasil
            </p>
            <p className="font-fraunces text-xl text-sand leading-tight">
              Uma equipe comprometida com cada etapa da sua jornada.
            </p>
          </div>
        </motion.div>

        {/* Right: Testimonials */}
        <div>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-inter text-xs tracking-ultra uppercase text-brass mb-8"
          >
            Depoimentos
          </motion.p>

          <motion.h2
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.1 }}
            className="font-fraunces text-4xl md:text-5xl text-sand mb-12 leading-tight"
          >
            O que nossos
            <br />
            <em className="display-italic text-brass">clientes dizem</em>
          </motion.h2>

          {/* Testimonial card */}
          <div className="relative min-h-[200px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={active}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
              >
                <div className="mb-6">
                  <svg
                    width="28"
                    height="20"
                    viewBox="0 0 28 20"
                    fill="none"
                    className="text-brass/40 mb-4"
                  >
                    <path
                      d="M0 20V12C0 5.373 4.477 1.12 13.43 0l1.14 2.14C10.1 3.1 7.84 5.65 7.27 9.5H12V20H0ZM16 20V12C16 5.373 20.477 1.12 29.43 0l1.14 2.14C26.1 3.1 23.84 5.65 23.27 9.5H28V20H16Z"
                      fill="currentColor"
                    />
                  </svg>
                  <p className="font-inter text-sm text-sand/70 leading-loose">
                    {testimonials[active].text}
                  </p>
                </div>
                <div>
                  <p className="font-fraunces text-sand text-lg">
                    {testimonials[active].author}
                  </p>
                  <p className="font-inter text-xs text-brass/60 tracking-widest uppercase mt-0.5">
                    {testimonials[active].context}
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Dots navigation */}
          <div className="flex gap-3 mt-10">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className={`h-px transition-all duration-300 ${
                  i === active
                    ? "w-10 bg-brass"
                    : "w-4 bg-sand/20 hover:bg-sand/40"
                }`}
                aria-label={`Depoimento ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
