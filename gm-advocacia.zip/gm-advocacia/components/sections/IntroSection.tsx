"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";

export default function IntroSection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], ["-8%", "8%"]);
  const textX = useTransform(scrollYProgress, [0, 1], ["-3%", "0%"]);

  return (
    <section
      ref={ref}
      className="relative bg-ink overflow-hidden"
      id="intro"
    >
      <div className="grid md:grid-cols-2 min-h-screen">
        {/* Left: Image bleeding out */}
        <motion.div
          className="relative overflow-hidden min-h-[50vh] md:min-h-screen"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <motion.div
            style={{ y: imageY }}
            className="absolute inset-0 scale-110"
          >
            <Image
              src="/images/gabriella-ambiente.jpeg"
              alt="Gabriella Magalhães — Advogada"
              fill
              className="object-cover object-center"
              priority
            />
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-ink/60" />
          </motion.div>
        </motion.div>

        {/* Right: Text block */}
        <motion.div
          style={{ x: textX }}
          className="flex flex-col justify-center px-10 py-20 md:px-16 md:py-24 bg-ink"
        >
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-inter text-xs tracking-ultra uppercase text-brass mb-8"
          >
            O Escritório
          </motion.p>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="font-fraunces text-4xl md:text-5xl text-sand leading-tight mb-8"
          >
            Cada decisão
            <br />
            <em className="display-italic text-brass">
              molda um futuro.
            </em>
          </motion.h2>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.25 }}
            className="space-y-5 text-sand/60 font-inter text-sm leading-loose max-w-sm"
          >
            <p>
              O Escritório Gabriella Magalhães foi criado com uma premissa
              simples: questões familiares e patrimoniais são, antes de tudo,
              decisões de vida — e merecem o mais alto nível de atenção jurídica.
            </p>
            <p>
              Com atuação em todo o Brasil, unimos rigor técnico, escuta
              empática e estratégia personalizada para cada cliente.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-14 flex gap-12"
          >
            {[
              { num: "500+", label: "Casos resolvidos" },
              { num: "10+", label: "Anos de experiência" },
              { num: "Brasil", label: "Atendimento nacional" },
            ].map(({ num, label }) => (
              <div key={label}>
                <p className="font-fraunces text-2xl text-brass">{num}</p>
                <p className="font-inter text-[11px] text-sand/40 tracking-widest uppercase mt-1">
                  {label}
                </p>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
