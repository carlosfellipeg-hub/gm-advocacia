"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";

export default function AutoridadeSection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const imgY = useTransform(scrollYProgress, [0, 1], ["-6%", "6%"]);
  const bgScale = useTransform(scrollYProgress, [0, 1], [1.05, 1]);

  return (
    <section
      ref={ref}
      className="relative bg-sand overflow-hidden py-28 md:py-40"
      id="autoridade"
    >
      {/* Background image with parallax */}
      <motion.div
        style={{ y: imgY, scale: bgScale }}
        className="absolute inset-0"
      >
        <Image
          src="/images/card-decisoes.jpeg"
          alt="GM Advocacia"
          fill
          className="object-cover object-center opacity-15"
        />
      </motion.div>

      {/* Tinted overlay */}
      <div className="absolute inset-0 bg-sand/80" />

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-8 md:px-16">
        {/* The signature statement */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="mb-20"
        >
          <p className="font-inter text-xs tracking-ultra uppercase text-brass mb-8">
            Nossa filosofia
          </p>
          <h2 className="font-fraunces text-5xl md:text-7xl lg:text-8xl text-ink leading-[0.9] tracking-tight">
            Decisões
            <br />
            familiares são
            <br />
            <em className="display-italic text-walnut">decisões</em>
            <br />
            <em className="display-italic text-walnut">econômicas.</em>
          </h2>
          <p className="font-inter text-sm text-ink/50 mt-8 max-w-sm leading-relaxed">
            Mesmo que ninguém as trate assim. Por isso, cada escolha jurídica
            deve ser feita com clareza, estratégia e plena consciência das
            implicações patrimoniais.
          </p>
        </motion.div>

        {/* Recognition row */}
        <hr className="rule-brass mb-14" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
          {[
            { icon: "⚖️", label: "OAB Regularizada" },
            { icon: "🏆", label: "Reconhecimento Nacional" },
            { icon: "🌐", label: "Atendimento em todo o Brasil" },
            { icon: "🤝", label: "Ética e transparência" },
          ].map(({ icon, label }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.1 }}
            >
              <span className="block text-2xl mb-3">{icon}</span>
              <p className="font-inter text-xs text-ink/60 leading-snug">
                {label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
