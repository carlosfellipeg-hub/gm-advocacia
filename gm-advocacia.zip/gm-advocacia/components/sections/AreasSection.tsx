"use client";

import { motion } from "framer-motion";

const areas = [
  {
    title: "Direito de Família",
    desc: "Divórcio, guarda, alimentos, reconhecimento de paternidade, união estável e planejamento conjugal preventivo.",
    tag: "Família",
  },
  {
    title: "Direito das Sucessões",
    desc: "Inventário, testamento, partilha de bens, planejamento sucessório e proteção do patrimônio para as próximas gerações.",
    tag: "Sucessões",
  },
  {
    title: "Direito Empresarial",
    desc: "Contratos, constituição e dissolução de sociedades, proteção patrimonial e conflitos societários.",
    tag: "Empresarial",
  },
  {
    title: "Direito Civil",
    desc: "Responsabilidade civil, contratos, reparação de danos, posse e propriedade.",
    tag: "Civil",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] },
  },
};

export default function AreasSection() {
  return (
    <section className="bg-sand py-28 md:py-40 px-8 md:px-16" id="areas">
      {/* Header */}
      <div className="mb-20 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-inter text-xs tracking-ultra uppercase text-brass mb-4"
          >
            Atuação
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="font-fraunces text-4xl md:text-6xl text-ink leading-tight"
          >
            Áreas de
            <br />
            <em className="display-italic text-walnut">especialidade</em>
          </motion.h2>
        </div>
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="font-inter text-sm text-ink/50 max-w-xs leading-relaxed"
        >
          Cada área de atuação é conduzida com profundidade técnica e
          comprometimento com o resultado do cliente.
        </motion.p>
      </div>

      {/* Thin rule */}
      <hr className="rule-brass mb-14" />

      {/* Areas grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-80px" }}
        className="grid md:grid-cols-2 gap-0"
      >
        {areas.map((area, i) => (
          <motion.div
            key={area.tag}
            variants={cardVariants}
            className={`group relative p-10 md:p-14 border-ink/10 hover:bg-ink transition-colors duration-500 cursor-default
              ${i % 2 === 0 ? "border-r" : ""}
              ${i < 2 ? "border-b" : ""}
            `}
          >
            <span className="font-inter text-[10px] tracking-ultra uppercase text-brass/60 group-hover:text-brass/80 block mb-6 transition-colors duration-300">
              {area.tag}
            </span>
            <h3 className="font-fraunces text-2xl md:text-3xl text-ink group-hover:text-sand mb-5 transition-colors duration-500 leading-tight">
              {area.title}
            </h3>
            <p className="font-inter text-sm text-ink/55 group-hover:text-sand/60 leading-relaxed transition-colors duration-500 max-w-xs">
              {area.desc}
            </p>

            {/* Arrow on hover */}
            <div className="absolute bottom-10 right-10 md:bottom-14 md:right-14 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <svg
                width="24"
                height="12"
                viewBox="0 0 24 12"
                fill="none"
                className="text-brass"
              >
                <path
                  d="M0 6H22M22 6L17 1M22 6L17 11"
                  stroke="currentColor"
                  strokeWidth="1.2"
                />
              </svg>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
