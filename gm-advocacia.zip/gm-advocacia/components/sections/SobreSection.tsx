"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";

export default function SobreSection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const img1Y = useTransform(scrollYProgress, [0, 1], ["-5%", "5%"]);
  const img2Y = useTransform(scrollYProgress, [0, 1], ["5%", "-5%"]);

  return (
    <section
      ref={ref}
      className="bg-ink py-28 md:py-40 px-8 md:px-16 overflow-hidden"
      id="sobre"
    >
      <div className="grid md:grid-cols-2 gap-16 md:gap-24 items-center max-w-7xl mx-auto">
        {/* Left: Overlapping photos */}
        <div className="relative h-[520px] md:h-[620px]">
          {/* Photo 1 — back */}
          <motion.div
            style={{ y: img1Y }}
            className="absolute top-0 left-0 w-[70%] h-[75%] rounded-sm overflow-hidden"
          >
            <Image
              src="/images/gabriella-estudio-1.jpeg"
              alt="Gabriella Magalhães"
              fill
              className="object-cover object-top"
            />
            <div className="absolute inset-0 bg-ink/20" />
          </motion.div>

          {/* Photo 2 — front, offset */}
          <motion.div
            style={{ y: img2Y }}
            className="absolute bottom-0 right-0 w-[65%] h-[70%] rounded-sm overflow-hidden border-4 border-ink shadow-2xl"
          >
            <Image
              src="/images/gabriella-estudio-2.jpeg"
              alt="Gabriella Magalhães — Advogada especialista"
              fill
              className="object-cover object-center"
            />
          </motion.div>

          {/* Decorative brass square */}
          <div className="absolute top-[35%] left-[30%] w-12 h-12 border border-brass/30 z-10" />
        </div>

        {/* Right: Text */}
        <div className="flex flex-col justify-center">
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-inter text-xs tracking-ultra uppercase text-brass mb-6"
          >
            A Advogada
          </motion.p>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="font-fraunces text-4xl md:text-5xl text-sand leading-tight mb-8"
          >
            Dra. Gabriella
            <br />
            <em className="display-italic text-brass">Magalhães</em>
          </motion.h2>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.25 }}
            className="space-y-4 text-sand/60 font-inter text-sm leading-loose"
          >
            <p>
              Advogada com sólida formação em Direito de Família e Sucessões,
              Gabriella Magalhães construiu sua carreira no convencimento de que
              o direito é, acima de tudo, uma ferramenta de proteção das pessoas.
            </p>
            <p>
              Com uma equipe multidisciplinar e atendimento humanizado, o
              escritório GM Advocacia oferece estratégias jurídicas que
              respeitam a complexidade de cada história — sem fórmulas prontas.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-10 pt-10 border-t border-sand/10"
          >
            <p className="font-fraunces text-xl text-brass italic mb-1">
              "O direito deve proteger sonhos, não apenas documentos."
            </p>
            <p className="font-inter text-xs text-sand/30 tracking-widest uppercase">
              — Gabriella Magalhães
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
