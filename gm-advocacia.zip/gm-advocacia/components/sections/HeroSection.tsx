"use client";

import { useRef } from "react";
import dynamic from "next/dynamic";
import { motion, useScroll, useTransform } from "framer-motion";

// Dynamic import to avoid SSR issues with R3F
const HeroScene = dynamic(
  () => import("@/components/3d/HeroScene").then((m) => m.HeroScene),
  { ssr: false }
);

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "25%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <section
      ref={ref}
      className="relative min-h-screen bg-sand overflow-hidden flex flex-col"
    >
      {/* Grain texture overlay */}
      <div
        className="pointer-events-none absolute inset-0 z-10 opacity-[0.03]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
          backgroundSize: "200px 200px",
        }}
      />

      {/* Top navigation */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="relative z-20 flex items-center justify-between px-8 py-7 md:px-16"
      >
        <span className="font-fraunces text-ink text-sm tracking-ultra uppercase">
          GM
        </span>
        <div className="hidden md:flex items-center gap-10">
          {["Áreas", "Sobre", "Contato"].map((item) => (
            <button
              key={item}
              className="font-inter text-ink/60 text-xs tracking-widest uppercase hover:text-ink transition-colors duration-300"
            >
              {item}
            </button>
          ))}
        </div>
        <a
          href="https://wa.me/5500000000000"
          target="_blank"
          rel="noopener noreferrer"
          className="font-inter text-xs tracking-widest uppercase border border-ink/30 text-ink px-5 py-2.5 hover:bg-ink hover:text-sand transition-all duration-300"
        >
          Consulta
        </a>
      </motion.nav>

      {/* Hero content */}
      <motion.div
        style={{ y, opacity }}
        className="relative z-20 flex-1 flex flex-col md:flex-row items-center justify-center px-8 md:px-16 gap-12 pb-16"
      >
        {/* Left: Typography */}
        <div className="flex-1 max-w-xl">
          <motion.p
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="font-inter text-xs tracking-ultra uppercase text-brass mb-6"
          >
            Advocacia Especializada
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="font-fraunces text-5xl md:text-7xl leading-[0.95] tracking-tight text-ink mb-8"
          >
            Direito que
            <br />
            <em className="display-italic text-walnut">protege</em>
            <br />
            o que importa.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="font-inter text-sm text-ink/60 leading-relaxed max-w-sm mb-10"
          >
            Família, patrimônio e legado tratados com a seriedade que merecem.
            Atendimento em todo o Brasil.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.1 }}
            className="flex items-center gap-4"
          >
            <a
              href="#contato"
              className="inline-block bg-ink text-sand font-inter text-xs tracking-widest uppercase px-8 py-4 hover:bg-walnut transition-colors duration-300"
            >
              Agendar Consulta
            </a>
            <a
              href="#areas"
              className="font-inter text-xs tracking-widest uppercase text-ink/50 hover:text-ink transition-colors duration-300 flex items-center gap-2"
            >
              Ver Áreas
              <svg width="16" height="8" viewBox="0 0 16 8" fill="none">
                <path d="M0 4H14M14 4L11 1M14 4L11 7" stroke="currentColor" strokeWidth="1" />
              </svg>
            </a>
          </motion.div>
        </div>

        {/* Right: 3D Plaque */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="flex-shrink-0 w-full max-w-[340px] md:max-w-[420px] h-[260px] md:h-[300px]"
        >
          <HeroScene />
        </motion.div>
      </motion.div>

      {/* Bottom scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
        className="relative z-20 flex justify-center pb-8"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center gap-2 text-ink/30"
        >
          <span className="font-inter text-[10px] tracking-ultra uppercase">
            Role
          </span>
          <svg width="1" height="32" viewBox="0 0 1 32">
            <line
              x1="0.5" y1="0" x2="0.5" y2="32"
              stroke="currentColor"
              strokeWidth="1"
            />
          </svg>
        </motion.div>
      </motion.div>
    </section>
  );
}
