"use client";

import { motion } from "framer-motion";

const WHATSAPP_NUMBER = "5500000000000"; // Substituir pelo número real
const WHATSAPP_MSG = encodeURIComponent(
  "Olá, Dra. Gabriella! Vim pelo site e gostaria de agendar uma consulta."
);

export default function ContatoSection() {
  return (
    <section
      className="bg-sand py-28 md:py-40 px-8 md:px-16"
      id="contato"
    >
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-20">
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-inter text-xs tracking-ultra uppercase text-brass mb-6"
          >
            Comece agora
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="font-fraunces text-5xl md:text-7xl text-ink leading-[0.9]"
          >
            Vamos conversar
            <br />
            <em className="display-italic text-walnut">sobre o seu caso.</em>
          </motion.h2>
        </div>

        <hr className="rule-brass mb-14" />

        <div className="grid md:grid-cols-2 gap-16 items-end">
          {/* Left: CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.2 }}
          >
            <p className="font-inter text-sm text-ink/60 leading-loose mb-10 max-w-sm">
              O primeiro passo é uma conversa. Entre em contato pelo WhatsApp
              e entendemos juntos como podemos ajudar você.
            </p>

            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-4 bg-ink text-sand font-inter text-xs tracking-widest uppercase px-10 py-5 hover:bg-walnut transition-colors duration-300"
            >
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="currentColor"
                className="text-brass"
              >
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
              </svg>
              Falar no WhatsApp
            </a>
          </motion.div>

          {/* Right: Contact info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.35 }}
            className="space-y-8"
          >
            {[
              {
                label: "Localização",
                value: "Atendimento em todo o Brasil",
              },
              {
                label: "Instagram",
                value: "@gabriellamagalhaesadv",
              },
              {
                label: "Horário",
                value: "Segunda a sexta, 8h–18h",
              },
            ].map(({ label, value }) => (
              <div key={label}>
                <p className="font-inter text-[10px] tracking-ultra uppercase text-ink/30 mb-1">
                  {label}
                </p>
                <p className="font-inter text-sm text-ink/70">{value}</p>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-24 pt-10 border-t border-ink/10 flex flex-col md:flex-row items-center justify-between gap-4"
        >
          <p className="font-fraunces text-2xl text-ink/20">GM</p>
          <p className="font-inter text-[10px] tracking-widest uppercase text-ink/30">
            © {new Date().getFullYear()} Gabriella Magalhães Advocacia
          </p>
          <p className="font-inter text-[10px] tracking-widest uppercase text-ink/30">
            OAB regularizada
          </p>
        </motion.div>
      </div>
    </section>
  );
}
