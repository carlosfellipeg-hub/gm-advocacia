"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { Environment, PresentationControls } from "@react-three/drei";
import { GMPlaque } from "./GMPlaque";

export function HeroScene() {
  return (
    <Canvas
      camera={{ position: [0, 0, 5], fov: 40 }}
      dpr={[1, 2]}
      style={{ width: "100%", height: "100%" }}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.4} />
      <directionalLight
        position={[5, 5, 5]}
        intensity={1.8}
        color="#fff8f0"
      />
      <directionalLight
        position={[-3, 2, -2]}
        intensity={0.6}
        color="#C9A668"
      />
      <pointLight position={[0, -3, 3]} intensity={0.8} color="#EFE9DC" />

      <Suspense fallback={null}>
        <Environment preset="studio" />
        <GMPlaque />
      </Suspense>
    </Canvas>
  );
}
