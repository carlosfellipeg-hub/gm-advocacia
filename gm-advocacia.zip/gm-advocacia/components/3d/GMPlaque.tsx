"use client";

import { useRef, useMemo } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { Text, RoundedBox, MeshDistortMaterial } from "@react-three/drei";
import * as THREE from "three";

export function GMPlaque() {
  const groupRef = useRef<THREE.Group>(null);
  const plaqueRef = useRef<THREE.Mesh>(null);
  const { mouse, size } = useThree();

  // Target rotation for mouse reaction
  const targetRotation = useRef({ x: 0, y: 0 });

  useFrame((state) => {
    if (!groupRef.current) return;

    const time = state.clock.elapsedTime;

    // Smooth mouse tracking
    targetRotation.current.x = mouse.y * -0.15;
    targetRotation.current.y = mouse.x * 0.2;

    groupRef.current.rotation.x +=
      (targetRotation.current.x - groupRef.current.rotation.x) * 0.05;
    groupRef.current.rotation.y +=
      (targetRotation.current.y - groupRef.current.rotation.y) * 0.05;

    // Subtle float animation
    groupRef.current.position.y = Math.sin(time * 0.6) * 0.06;
  });

  // Brass material
  const brassMaterial = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: new THREE.Color("#C9A668"),
        metalness: 0.85,
        roughness: 0.25,
        envMapIntensity: 1.2,
      }),
    []
  );

  const plateMaterial = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: new THREE.Color("#B8924A"),
        metalness: 0.9,
        roughness: 0.2,
        envMapIntensity: 1.5,
      }),
    []
  );

  return (
    <group ref={groupRef}>
      {/* Main plaque body */}
      <RoundedBox
        ref={plaqueRef}
        args={[3.2, 1.8, 0.12]}
        radius={0.06}
        smoothness={4}
        material={plateMaterial}
      />

      {/* Monogram GM */}
      <Text
        position={[0, 0.12, 0.07]}
        fontSize={0.72}
        font={undefined}
        color="#EFE9DC"
        anchorX="center"
        anchorY="middle"
        letterSpacing={0.08}
        material-metalness={0.3}
        material-roughness={0.4}
      >
        GM
      </Text>

      {/* Subtitle */}
      <Text
        position={[0, -0.42, 0.07]}
        fontSize={0.13}
        font={undefined}
        color="#EFE9DC"
        anchorX="center"
        anchorY="middle"
        letterSpacing={0.2}
        material-opacity={0.75}
        material-transparent={true}
      >
        ADVOCACIA ESPECIALIZADA
      </Text>

      {/* Thin border lines */}
      <lineSegments position={[0, 0, 0.065]}>
        <edgesGeometry
          args={[new THREE.BoxGeometry(3.0, 1.6, 0.001)]}
        />
        <lineBasicMaterial color="#D4AF70" transparent opacity={0.4} />
      </lineSegments>
    </group>
  );
}
